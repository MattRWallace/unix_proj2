Custom Shell
============

In order for custom commands to be found the current directory needs to 
be added to the PATH environmental variable.

    . update_path.sh


